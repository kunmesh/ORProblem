package com.org.scm.DTO;

public class InventoryDetails {
	int quantity;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int qty) {
		quantity = qty;
	}

}
