package com.org.scm.DTO;

public class OrderDetails {

	int quantity;

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int qty) {
		quantity = qty;
	}

}
